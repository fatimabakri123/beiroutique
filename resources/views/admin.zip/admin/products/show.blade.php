@extends('admin.layout')

@section('title', 'Product Details')

@section('content')
<div class="card p-4">
    <h3>{{ $product->product_name }}</h3>

    @php
        $images = collect();

        if ($product->images && $product->images->count()) {
            $images = $product->images;
        } elseif (!empty($product->image_url)) {
            $images = collect([(object)['image_path' => $product->image_url]]);
        }
    @endphp

    {{-- Images --}}
    <div class="product-gallery">
        @forelse($images as $img)
            <img
                src="{{ Str::startsWith($img->image_path, 'products/')
                        ? asset('storage/'.$img->image_path)
                        : asset($img->image_path) }}"
                alt="{{ $product->product_name }}">
        @empty
            <img src="{{ asset('images/no-image.png') }}" alt="No image">
        @endforelse
    </div>

    <p><strong>Price:</strong> ${{ $product->price }}</p>
    <p><strong>Description:</strong> {{ $product->description }}</p>
    <p><strong>Stock:</strong> {{ $product->stock_quantity }}</p>
    <p><strong>SKU:</strong> {{ $product->sku }}</p>
</div>

<style>
.card {
    max-width: 650px;
    margin: 30px auto;
    background: #fff;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 12px 30px rgba(124, 77, 255, 0.08);
    transition: all 0.3s ease;
}
.card:hover {
    transform: translateY(-3px);
    box-shadow: 0 18px 40px rgba(124, 77, 255, 0.15);
}

.card h3 {
    font-size: 26px;
    font-weight: 700;
    color: #6311ac;
    margin-bottom: 20px;
    text-align: center;
}

.product-gallery {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    justify-content: center;
    margin-bottom: 20px;
}
.product-gallery img {
    width: 160px;
    height: 160px;
    object-fit: cover;
    border-radius: 14px;
    border: 1px solid #eee;
    transition: all 0.3s ease;
}
.product-gallery img:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(124,77,255,0.25);
}

.card p {
    font-size: 15px;
    color: #555;
    margin: 6px 0;
}
.card p strong {
    color: #2c3e50;
}

@media (max-width: 768px) {
    .product-gallery img {
        width: 120px;
        height: 120px;
    }
}
</style>

@endsection
