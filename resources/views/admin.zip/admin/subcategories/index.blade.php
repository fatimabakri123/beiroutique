@extends('admin.layout')

@section('content')
<div class="container">
    <h2>Add New Subcategory</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('admin.subcategories.store') }}">
        @csrf

        <div class="mb-3">
            <label>Subcategory Name</label>
            <input type="text" name="subcategory_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <select name="category_id" class="form-control" required>
                <option value="">Select Category</option>
                @foreach($categories as $cat)
                    <option value="{{ $cat->category_id }}">
                        {{ $cat->category_name }}
                    </option>
                @endforeach
            </select>
        </div>

       <button type="submit" class="add-btn">Add Subcategory</button>

    </form>

    <hr>

    <h4>All Subcategories</h4>
    <table class="table table-bordered mt-3">
        <tr>
            <th>ID</th>
            <th>Subcategory</th>
            <th>Category</th>
        </tr>
        @foreach($subcategories as $sub)
        <tr>
            <td>{{ $sub->subcategory_id }}</td>
            <td>{{ $sub->subcategory_name }}</td>
            <td>{{ $sub->category->category_name }}</td>
        </tr>
        @endforeach
    </table>
    {{-- Pagination --}}
<div class="mt-3">
    {{ $subcategories->links('pagination::bootstrap-5') }}
</div>

</div>
<style>
    /* ===== PAGE TITLE ===== */
h2 {
    color: var(--primary);
    font-weight: 700;
    font-size: 28px;
    margin-bottom: 20px;
    position: relative;
}


h2::after {
    content: '';
    display: block;
    width: 60px;
    height: 4px;
    background: var(--primary);
    border-radius: 2px;
    margin-top: 6px;
}

:root {
    --primary: #7b2fae;
    --bg-light: #f4f6fa;
    --card: #fff;
    --text: #2c3e50;
    --muted: #7f8c8d;
    --shadow: 0 6px 18px rgba(124,77,255,0.08);
    --shadow-hover: 0 10px 25px rgba(124,77,255,0.15);
}
/* ===== CUSTOM BUTTON ===== */
.add-btn {
   background: linear-gradient(135deg, #a080bc, #5b93c7);
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 10px 25px;
    border-radius: 12px;
    transition: all 0.3s ease;
    cursor: pointer;
}
.add-btn:hover {
    background: #6311ac;
    transform: translateY(-2px);
}


/* ===== CONTAINER ===== */
.container {
    max-width: 900px;
    margin: 30px auto;
    padding: 0 15px;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

/* ===== FORM CARD ===== */
form {
    background: var(--card);
    padding: 20px 25px;
    border-radius: 16px;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
}
form:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-hover);
}

form .mb-3 label {
    font-weight: 600;
    color: var(--primary);
    margin-bottom: 5px;
}
form .mb-3 input,
form .mb-3 select {
    padding: 8px 12px;
    border-radius: 8px;
    border: 1px solid #ccc;
    width: 100%;
    font-size: 14px;
}
form button {
    background: ;
    color: #fff;
    font-weight: 600;
    border: none;
    padding: 10px 20px;
    border-radius: 12px;
    transition: all 0.3s ease;
}
form button:hover {
    background: #6311ac;
    transform: translateY(-2px);
}

/* ===== ALERT ===== */
.alert {
    border-radius: 12px;
    box-shadow: var(--shadow);
}

/* ===== TABLE ===== */
table {
    width: 100%;
    background: var(--card);
    border-radius: 12px;
    box-shadow: var(--shadow);
    border-collapse: separate;
    border-spacing: 0;
}
table th, table td {
    padding: 12px 15px;
    text-align: left;
    font-size: 14px;
    color: var(--text);
}
table th {
    background: var(--bg-light);
    font-weight: 600;
}
table tr:not(:last-child) {
    border-bottom: 1px solid #eee;
}

/* ===== RESPONSIVE ===== */
@media(max-width:768px){
    table th, table td { font-size: 13px; padding: 10px; }
    form { padding: 15px; }
}
</style>
@endsection
