<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminNotification;
use App\Models\User;
use Illuminate\Http\Request;

class AdminNotificationController extends Controller
{
    public function index()
    {
        $notifications = AdminNotification::latest()->paginate(30);
        return view('admin.notifications.index', compact('notifications'));
    }

    public function send(Request $r)
    {
        $r->validate([
            'target' => 'required',
            'message' => 'required|string'
        ]);

        // store notification record
        AdminNotification::create([
            'target' => $r->target,
            'message' => $r->message,
            'admin_id' => auth()->id(),
            'title' => $r->title ?? null
        ]);

        // dispatch to users manually (optional logic if you need to mark something in users)
        if ($r->target == 'all') {
            // مثال: فقط عمل update لكل المستخدمين أو إرسال رسالة وهمية
            User::chunk(200, function ($users) {
                foreach ($users as $user) {
                    // إذا بدك تعمل أي منطق خاص لكل مستخدم، تضيفه هنا
                    // مثلًا: $user->notify_status = 'new notification'; $user->save();
                }
            });
        }

        return redirect()->back()->with('success', 'Notification sent successfully.');
    }
}
