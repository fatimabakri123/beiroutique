<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\orders as Order;
use Illuminate\Http\Request;

class AdminOrderController extends Controller {
    public function index(){
        $orders = Order::with('customer')->latest()->paginate(20);
        return view('admin.orders.index', compact('orders'));
    }
    public function show(Order $order){
        return view('admin.orders.show', ['order'=>$order->load('items.product','customer')]);
    }
    public function updateStatus(Request $r, Order $order){
        $r->validate(['status'=>'required|string']);
        $order->order_status = $r->status;
        $order->save();
        return redirect()->back()->with('success','Status updated');
    }
    public function destroy(Order $order){
        $order->delete();
        return redirect()->route('admin.orders.index')->with('success','Deleted');
    }
}
