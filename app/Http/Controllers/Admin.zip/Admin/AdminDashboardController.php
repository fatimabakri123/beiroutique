<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Shop;
use App\Models\products as Product;
use App\Models\orders as Order;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller {
    public function index(){
        $customerCount = User::where('role','customer')->count();
        $shopCount = Shop::count();
        $productCount = Product::count();
        $orderCount = Order::count();

        // Example sales chart data (last 7 days)
        $sales = Order::selectRaw("DATE(order_date) as day, SUM(total_amount) as total")
                ->where('order_date','>=', now()->subDays(6))
                ->groupBy('day')->orderBy('day')->get();
      $labels = $sales->pluck('day');  // جاهز already

        $data = $sales->pluck('total');

        return view('admin.dashboard', compact('customerCount','shopCount','productCount','orderCount','labels','data'))
            ->with('labels', $labels->toArray())
            ->with('data', $data->toArray());
    }
}
