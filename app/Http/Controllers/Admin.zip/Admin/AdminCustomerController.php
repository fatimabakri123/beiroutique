<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Customer;
use App\Models\orders as Order;
use Illuminate\Http\Request;

class AdminCustomerController extends Controller {
    public function index()
{
    $customers = User::where('role', 'customer')->paginate(10);
    $orders = Order::all();
    return view('admin.customers.index', compact('customers'));
}

   public function show($id)
{
    // جلب الـ Customer بدل الـ User
    $customer = Customer::find($id);

    if (!$customer) {
        return redirect()->route('customers.index')->with('error', 'Customer not found');
    }

    // جلب كل الطلبات الخاصة بالـ Customer
    $orders = $customer->orders;

    return view('admin.customers.show', compact('customer', 'orders'));
}

   // AdminCustomerController
public function destroy($customer_id)
{
    $customer = Customer::findOrFail($customer_id); // <- تأكد أن تستخدم الـ model الصحيح
    $customer->delete();
    return redirect()->route('admin.customers.index')->with('success', 'Customer deleted successfully.');
}

   public function toggleStatus($customer_id)
{
    $customer = Customer::find($customer_id);
    if ($customer) {
        $customer->status = !$customer->status; // تغيير الحالة
        $customer->save();
    }
    return redirect()->back()->with('success', 'Customer status updated.');
}


}