<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\ShopOwner;
use Illuminate\Http\Request;

class AdminShopOwnerController extends Controller {
    public function index(){
   $owners = ShopOwner::with('user', 'shops', 'shops.products')
                   ->withCount('shops')
                   ->orderBy('created_at', 'desc')

                  ->paginate(10); 


        return view('admin.shopowners.index', compact('owners'));
    }
   public function show($shopownerId){
    $owner = ShopOwner::with('shops.products')->findOrFail($shopownerId);
    return view('admin.shopowners.show', ['owner'=>$owner]);
}

    public function destroy($shopownerId){
        $owner = ShopOwner::findOrFail($shopownerId);
        $owner->delete();
        return redirect()->route('admin.shopowners.index')->with('success','Deleted');
    }
}
