<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Shop;
use Illuminate\Http\Request;

class AdminShopController extends Controller {
    public function index(){
        $shops = Shop::with('owner')->withCount('products')->paginate(20);
        return view('admin.shops.index', compact('shops'));
    }
    public function show(Shop $shop){
        return view('admin.shops.show', ['shop'=>$shop->load('products','owner')]);
    }
    public function approve(Shop $shop){
        $shop->is_active = true;
        $shop->save();
        return redirect()->back()->with('success','Approved');
    }
    public function destroy(Shop $shop){
        $shop->delete();
        return redirect()->route('admin.shops.index')->with('success','Deleted');
    }
}
