<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\products as Product;
use Illuminate\Http\Request;

class AdminProductController extends Controller {
    public function index(){
        $products = Product::with('shop','category')->paginate(20);
        return view('admin.products.index', compact('products'));
    }
    public function pending(){
        $pending = Product::where('is_active', false)->paginate(20);
        return view('admin.products.pending', compact('pending'));
    }
    public function show(Product $product){
        return view('admin.products.show', compact('product'));
    }
    public function approve(Product $product){
        $product->is_active = true;
        $product->save();
        return redirect()->back()->with('success','Approved');
    }
    public function reject(Product $product){
        $product->delete();
        return redirect()->back()->with('success','Rejected');
    }
    public function destroy(Product $product){
        $product->delete();
        return redirect()->route('admin.products.index')->with('success','Removed');
    }
}
