<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\PaymentMethod;
use Illuminate\Http\Request;

class AdminPaymentMethodController extends Controller {
    public function index(){
        $methods = PaymentMethod::all();
        return view('admin.payment_methods.index', compact('methods'));
    }
    public function store(Request $r){
        $r->validate(['method_name'=>'required']);
        PaymentMethod::create(['method_name'=>$r->method_name,'is_active'=>true]);
        return redirect()->back();
    }
    public function toggle($id){
        $m = PaymentMethod::findOrFail($id);
        $m->is_active = !$m->is_active; $m->save();
        return redirect()->back();
    }
}
